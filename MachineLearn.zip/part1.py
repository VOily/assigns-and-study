import numpy as np
import math

mean1 = [1, 3]
mean2 = [10, 20]
# np.mat是np中代表矩阵的数据结构
vai1 = np.mat([[2, 0], [0, 2]])
vai2 = np.mat([[10, 0], [0, 10]])
# 随机生成两类数据
result1 = np.random.multivariate_normal(mean1, vai1, 10000)
result2 = np.random.multivariate_normal(mean2, vai2, 20000)
mean1 = np.mat(mean1)
mean2 = np.mat(mean2)
# 最小错误的各计数
countz = 0
countf = 0
# 最小风险的各计数
cz = 0
cf = 0

for x in result1:
    x = np.mat(x)
    # 计算两类下的后验概率
    p1 = math.exp(-0.5 * (x - mean1) * vai1.I * (x - mean1).T) / (2 * np.pi * np.linalg.det(vai1))
    p2 = math.exp(-0.5 * (x - mean2) * vai2.I * (x - mean2).T) / (2 * np.pi * np.linalg.det(vai2))
    # 最小错误
    r = p1 / 3
    w = p2 / 3 * 2
    if r > w:
        countz += 1
    # 最小风险
    r = r * 0.6
    w = w * 0.4
    if r > w:
        cz += 1

for x in result2:
    x = np.mat(x)
    p1 = math.exp(-0.5 * (x - mean1) * vai1.I * (x - mean1).T) / (2 * np.pi * np.linalg.det(vai1))
    p2 = math.exp(-0.5 * (x - mean2) * vai2.I * (x - mean2).T) / (2 * np.pi * np.linalg.det(vai2))
    # 最小错误
    w = p1 / 3
    r = p2 / 3 * 2
    if r > w:
        countf += 1
    # 最小风险
    r = r * 0.4
    w = w * 0.6
    if r > w:
        cf += 1

print('最小错误率：')
print("正 正确率:", (countz/10000))
print("负 正确率:", (countf/20000))
print('最小风险率：')
print("正 正确率:", (cz/10000))
print("负 正确率:", (cf/20000))
