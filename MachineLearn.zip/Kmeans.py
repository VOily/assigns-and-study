import random
import math


def cal_distance(x1, x2):
    # 第一项是类别 计算时从1开始计算距离
    dimension = len(x1) - 1
    tem = 0
    for i in range(dimension):
        tem += math.pow(x1[i + 1] - x2[i + 1], 2)
    return math.sqrt(tem)


def min(x1, x2, x3):
    mm = x1
    temp_c = 0
    if mm > x2:
        mm = x2
        temp_c = 1
    if mm > x3:
        mm = x3
        temp_c = 2
    return temp_c


def cal_means(c):
    temp_len = len(c)
    dimension = len(c[0]) - 1
    u = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    for item in c:
        for i in range(dimension + 1):
            u[i] += item[i]
    for i in range(dimension + 1):
        u[i] = u[i]/temp_len
    return u


def cal_ratio(Class):
    for c in Class:
        num = [0, 0, 0]
        for item in c:
            num[item[0] - 1] += 1
        print("class 1:", num[0], "\tclass 2:", num[1], "\tclass 3:", num[2])


f = open('Winedataset.txt', 'r')
all = f.readlines()
data = []
for a in all:
    temp = a.split(",")
    temp[0] = int(temp[0])
    temp[1] = float(temp[1])
    temp[2] = float(temp[2])
    temp[3] = float(temp[3])
    temp[4] = float(temp[4])
    temp[5] = float(temp[5])
    temp[6] = float(temp[6])
    temp[7] = float(temp[7])
    temp[8] = float(temp[8])
    temp[9] = float(temp[9])
    temp[10] = float(temp[10])
    temp[11] = float(temp[11])
    temp[12] = float(temp[12])
    temp[13] = int(temp[13])
    data.append(temp)
    pass
length = len(data)
u1 = data[random.randint(0, length - 1)]
u2 = data[random.randint(0, length - 1)]
u3 = data[random.randint(0, length - 1)]
C = [[u1], [u2], [u3]]
for k in range(100):
    for item in data:
        t1 = cal_distance(u1, item)
        t2 = cal_distance(u2, item)
        t3 = cal_distance(u3, item)
        C[min(t1, t2, t3)].append(item)
    print("k :", k)
    cal_ratio(C)
    temp1 = cal_means(C[0])
    temp2 = cal_means(C[1])
    temp3 = cal_means(C[2])
    # 提前终止循环
    if temp1 == u1 and temp2 == u2 and temp3 == u3:
        break
    else:
         u1 = temp1
         u2 = temp2
         u3 = temp3
    C = [[], [], []]
print()

