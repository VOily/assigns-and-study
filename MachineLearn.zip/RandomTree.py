"""
    在决策树实验的基础上进行修改，去掉剪枝操作
    增加addbeach的参数：属性选择
    因为属性数为4 log2(4) = 2 ，则每一个随机树选择两个属性
    Bootstrap方式实现差异性
"""
from math import log
import random


def dataTest(TREE, test_set):
    false = 0
    true = 0
    for item in test_set:
        num = 0
        node = TREE[num]
        # 根据已知模型分类每条数据
        while type(node) != str:
            if item[node] < division_point[node]:
                num = num * 2 + 1
            else:
                num = num * 2 + 2
            node = TREE[num]
        if item[4] == node:
            true += 1
        else:
            false += 1
    return true, false


# 计算当前subset划分最佳属性并加入TREE
def addBeach(TREE, subset, selection):
    if type(TREE[subset]) != list:
        return
    # 根据增益向tree增加新节点temp
    feture = calBest(TREE[subset], division_point, selection)
    # 检查是否还能划分
    if feture == -1:
        makeLeaf(TREE, subset)
        return
    # 划分
    left = []
    right = []
    for b in TREE[subset]:
        if b[feture] < division_point[feture]:
            left.append(b)
        else:
            right.append(b)
    # 取消剪枝
    TREE[subset*2+1] = left
    TREE[subset*2+2] = right
    TREE[subset] = feture


# data是包含全部属性的数据， division是所有连续属性的划分点
# 计算当下最优属性 默认Gain值为0 最佳属性为-1代表null return 则默认返回-1代表所有的增益为负数
def calBest(dataset, division, selection):
    le = len(dataset)
    best_feture = -1
    Gain = 0
    # 对选择的属性计算增益
    for feture in selection:
        # 预备数据结构存储计算px
        typeL = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
        typeR = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
        types = list(typeL.keys())
        # 划分集合 划分点在右集合
        di = division[feture]
        left = 0
        right = 0
        for b in dataset:
            if b[feture] < di:
                left += 1
                typeL[b[4]] += 1
            else:
                right += 1
                typeR[b[4]] += 1
            pass
        DtDL = left / le
        DtDR = right / le
        # 这几个忽略了负号
        EntL = 0
        EntR = 0
        Ent = 0
        for tt in types:
            if typeL[tt] != 0:
                EntL += (typeL[tt] / left) * log((typeL[tt] / left), 2)
            if typeR[tt] != 0:
                EntR += (typeR[tt] / right) * log((typeR[tt] / right), 2)
            if (typeL[tt] != 0) | (typeR[tt] != 0):
                px = (typeR[tt] + typeL[tt]) / le
                Ent += px * log(px, 2)
            pass
        TEMP = -Ent - (DtDL * (-EntL) + DtDR * (-EntR))
        # 最大值
        if Gain < TEMP:
            Gain = TEMP
            best_feture = feture
            pass
        pass
    return best_feture


# 将子集替换成叶节点
def makeLeaf(TREE, subset):
    # se = 0 ve = 0 vi = 0
    re = [0, 0, 0]
    for item in TREE[subset]:
        if item[4] == 'Iris-virginica':
            re[2] += 1
        elif item[4] == 'Iris-setosa':
            re[0] += 1
        else:
            re[1] += 1
    # 概率最大的作为叶节点
    re = re.index(max(re))
    if re == 2:
        TREE[subset] = 'Iris-virginica'
    elif re == 0:
        TREE[subset] = 'Iris-setosa'
    elif re == 1:
        TREE[subset] = 'Iris-versicolor'


f = open('iris.data', 'r')
ll = f.readlines()
data = []
for a in ll:
    temp = a.split(",")
    temp[0] = float(temp[0])
    temp[1] = float(temp[1])
    temp[2] = float(temp[2])
    temp[3] = float(temp[3])
    temp[4] = temp[4][:-1]
    data.append(temp)
    pass
# 存储连续值的最佳中值 实验结果表示第三个属性的中值表现最差
# 当使用这组中值时正确率大幅度上升
division_point = [5.55, 3.4, 4.7, 1.0]
# division_point = [5.55, 3.4, 3.15, 1.0]
division_Gain = [0.55, 0.26, 0.87, 0.92]
trees = []
tree_num = 50
len_data = len(data)
# bootstrap
for part in range(tree_num):  # 树个数
    # 初始化决策树 大小为7个节点 初始化值为-1作为null的代替
    tree = []
    select1 = random.randint(0, 3)
    select2 = random.randint(0, 3)
    while select2 == select1:
        select2 = random.randint(0, 3)
    selection = [select1, select2]
    for i in range(7):
        tree.append(-1)
    tree[0] = []
    # 数据抽取mark
    for i in range(len_data):
        tree[0].append(data[random.randint(0, len_data-1)])
    for j in range(7):
        addBeach(tree, j, selection)
    print('tree is created, feature : ', selection)
    trees.append(tree)


# 对data中的数据进行投票
true_num = 0
false_num = 0
for item in data:
    types = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
    for t in trees:
        num = 0
        node = t[num]
        # 根据已知模型分类每条数据
        while type(node) != str:
            if int(item[node]) < division_point[node]:
                num = num * 2 + 1
            else:
                num = num * 2 + 2
            node = t[num]
        types[str(node)] += 1
    # 计算正确率
    if item[4] == max(zip(types.values(), types.keys()))[1]:
        true_num += 1
    else:
        false_num += 1
print('avg accuracy: ', round(true_num/(false_num+true_num), 5))


