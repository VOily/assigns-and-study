"""
对于决策树创建（branch）伪代码：
def createBranch(子集):
If 能够分类正确 return 类标签：
Else
     寻找划分数据集的最好特征
     划分数据集
     创建分支节点
         for 每个划分的子集
             增加分支节点 = createBranch(子集)
         return 分支节点
"""

"""
信息增益计算：
L(Xi) = -log2 p(Xi)  p(x)为分类集中的概率
//经验熵
H(D) = -{{ p(Xi) * log2 p(Xi)  累加/n为分类数量（属性取值个数）
//条件熵 
H(Y/X) = {{ p(Xi) * H(Y/Xi)
以上两个的概率由极大似然估计得到
//信息增益
G(D,A) = H(D) - H(D/A) D为数据集，A为某一特征
       = H(D) - sum( p(xi)*H(Di) )
//信息增益比则再除以经验熵
"""

"""
五折交叉验证/过拟合
预剪枝、后剪枝/测试集和训练集的准确率
"""

"""
对于离散值处理：二分后信息增益选取
对于同意属性所有离散值排序后两两取中值
选取信息增益最大的中值
"""
from math import log


def dataTest(TREE, test_set):
    false = 0
    true = 0
    for item in test_set:
        num = 0
        node = TREE[num]
        # 根据已知模型分类每条数据
        while type(node) != str:
            if item[node] < division_point[node]:
                num = num * 2 + 1
            else:
                num = num * 2 + 2
            node = TREE[num]
        if item[4] == node:
            true += 1
        else:
            false += 1
    return true, false


# 计算当前subset划分最佳属性并加入TREE data用于prepruning
def addBeach(TREE, subset, validation):
    if type(TREE[subset]) != list:
        return
    # 根据增益向tree增加新节点tempp
    feture = calBest(TREE[subset], division_point)
    # 检查是否还能划分
    if feture == -1:
        makeLeaf(TREE, subset)
        return
    # 划分并预剪枝
    left = []
    right = []
    for b in TREE[subset]:
        if b[feture] < division_point[feture]:
            left.append(b)
        else:
            right.append(b)
    if preprun(TREE, subset, validation, feture):
        TREE[subset * 2 + 1] = left
        TREE[subset * 2 + 2] = right
        TREE[subset] = feture
    else:
        makeLeaf(TREE, subset)


# 预剪枝 验证集在划分前后的正确率
def preprun(TREE, subset, validation, feture):
    label = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
    for item in TREE[subset]:
        label[item[4]] += 1
    leaf = max(label)
    num = 0
    count = 0
    for va in validation:
        if va[4] == leaf:
            num += 1
        count += 1
    before = num / count
    left = []
    right = []
    for b in validation:
        if b[feture] < division_point[feture]:
            left.append(b)
        else:
            right.append(b)
    label = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
    for item in left:
        label[item[4]] += 1
    leaf = max(label)
    num = 0
    count = 0
    for va in validation:
        if va[4] == leaf:
            num += 1
        count += 1
    after = num / count
    return after >= before


def postprun(TREE, validation):
    # 划分并后剪枝
    left = []
    right = []
    node = 0
    for item in validation:
        num = 0
        node = TREE[num]
        # 根据已知模型分类每条数据
        while type(node) != str:
            if item[node] < division_point[node]:
                num = num * 2 + 1
            else:
                num = num * 2 + 2
            node = TREE[num]
        # 划分完成后加入叶节点
        # if item[4] == node:

    return


# 检查当前节点是否全为同一类别/停止划分选用 有更加好的方法
def check(NODE):
    # 检查是否为list
    if type(NODE) == list:
        sample = NODE[0][4]
        for sub in NODE:
            if sub[4] != sample:
                return False
    return True


# data是包含全部属性的数据， division是所有连续属性的划分点
# 计算当下最优属性 默认Gain值为0 最佳属性为-1代表null return 则默认返回-1代表所有的增益为负数
def calBest(dataset, division):
    le = len(dataset)
    best_feture = -1
    Gain = 0
    feture = 0
    # 对每个属性计算增益
    for di in division:
        # 预备数据结构存储计算px
        typeL = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
        typeR = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
        types = list(typeL.keys())
        # 划分集合 划分点在右集合
        left = 0
        right = 0
        for b in dataset:
            if b[feture] < di:
                left += 1
                typeL[b[4]] += 1
            else:
                right += 1
                typeR[b[4]] += 1
            pass
        DtDL = left / le
        DtDR = right / le
        # 这几个忽略了负号
        EntL = 0
        EntR = 0
        Ent = 0
        for tt in types:
            if typeL[tt] != 0:
                EntL += (typeL[tt] / left) * log((typeL[tt] / left), 2)
            if typeR[tt] != 0:
                EntR += (typeR[tt] / right) * log((typeR[tt] / right), 2)
            if (typeL[tt] != 0) | (typeR[tt] != 0):
                px = (typeR[tt] + typeL[tt]) / le
                Ent += px * log(px, 2)
            pass
        TEMP = -Ent - (DtDL * (-EntL) + DtDR * (-EntR))
        # 最大值
        if Gain < TEMP:
            Gain = TEMP
            best_feture = feture
            pass
        feture += 1
        pass
    return best_feture


# 叶节点的计算 基于loss_gain的计算
def calLoss(TREE, node):
    # 预备数据结构
    label = {"Iris-setosa": 0, "Iris-versicolor": 0, "Iris-virginica": 0}
    types = list(label.keys())
    for b in TREE[node]:
        label[b[4]] += 1
    # 这几个同样忽略了负号
    Ht = 0
    for tt in types:
        if label[tt] != 0:
            px = label[tt] / len(TREE[node])
            Ht += px * log(px, 2)
        pass


# 将子集替换成叶节点
def makeLeaf(TREE, subset):
    # se = 0 ve = 0 vi = 0
    re = [0, 0, 0]
    for item in TREE[subset]:
        if item[4] == 'Iris-virginica':
            re[2] += 1
        elif item[4] == 'Iris-setosa':
            re[0] += 1
        else:
            re[1] += 1
    # 概率最大的作为叶节点
    re = re.index(max(re))
    if re == 2:
        TREE[subset] = 'Iris-virginica'
    elif re == 0:
        TREE[subset] = 'Iris-setosa'
    elif re == 1:
        TREE[subset] = 'Iris-versicolor'


f = open('iris.data', 'r')
ll = f.readlines()
data = []
for a in ll:
    temp = a.split(",")
    temp[0] = float(temp[0])
    temp[1] = float(temp[1])
    temp[2] = float(temp[2])
    temp[3] = float(temp[3])
    temp[4] = temp[4][:-1]
    data.append(temp)
    pass
# 存储连续值的最佳中值 实验结果表示第三个属性的中值表现最差
# division_point = [5.55, 3.4, 4.7, 1.0]
# 当使用这组中值时正确率大幅度上升
division_point = [5.55, 3.4, 3.15, 1.0]
division_Gain = [0.55, 0.26, 0.87, 0.92]
# 分成五份
partition = [[], [], [], [], []]
for z in range(len(data)):
    partition[z % 5].append(data[z])
# 五折交叉验证
right_num = 0
false_num = 0
for part in range(5):
    # 初始化决策树 大小为15个节点 初始化值为-1作为null的代替
    tree = []
    for i in range(15):
        tree.append(-1)
    tree[0] = partition[part]
    for j in range(15):
        # 此处暂用data作为validation set
        addBeach(tree, j, data)
    print('tree is created')
    # 计算正确率
    for test in range(5):
        if test != part:
            num1, num2 = dataTest(tree, partition[test])
            right_num += num1
            false_num += num2
            print('accuracy of tree in validation set: ', round(num1 / (num1 + num2), 2))
        else:
            num1, num2 = dataTest(tree, partition[test])
            # 训练集的正确率
            print('accuracy of tree in train set: ', round(num1 / (num1 + num2), 2))
print('avg accuracy: ', round(right_num / (false_num + right_num), 2))
