from typing import Dict, Any


def train(data_, buying_, maint_, door_, person_, lugboot_, safety_, px_):
    # 条件概率计算
    for item in data_:
        # 类别对应各属性的总数
        buying_[item[6]][item[0]] += 1
        maint_[item[6]][item[1]] += 1
        door_[item[6]][item[2]] += 1
        person_[item[6]][item[3]] += 1
        lugboot_[item[6]][item[4]] += 1
        safety_[item[6]][item[5]] += 1
        # 同属性下每个类别的总数
        buying_[item[6]]['tol'] += 1
        maint_[item[6]]['tol'] += 1
        door_[item[6]]['tol'] += 1
        person_[item[6]]['tol'] += 1
        lugboot_[item[6]]['tol'] += 1
        safety_[item[6]]['tol'] += 1
        px_[item[6]] += 1
        pass
    px_['tol'] += len(data_)
    # 先验概率


def test(example_, buying_, maint_, door_, person_, lugboot_, safety_, px_, ave):
    # 计算后验概率
    caltor = list(px_.keys())
    caltor.pop()
    prob = 0
    for ex in example_:
        re = []
        for ca in caltor:
            p1 = buying_[ca][ex[0]] / buying_[ca]['tol']
            p2 = maint_[ca][ex[1]] / maint_[ca]['tol']
            p3 = door_[ca][ex[2]] / door_[ca]['tol']
            p4 = person_[ca][ex[3]] / person_[ca]['tol']
            p5 = lugboot_[ca][ex[4]] / lugboot_[ca]['tol']
            p6 = safety_[ca][ex[5]] / safety_[ca]['tol']
            re.append(px_[ca] * p1 * p2 * p3 * p4 * p5 * p6)
        if ex[6] == caltor[re.index(max(re))]:
            prob += 1
    # 分步计算每一则的结果
    re = prob/len(example_)
    print(re)
    ave['aver'] += re
    pass


f = open('car.data', 'r')
ll = f.readlines()
list_len: int = len(ll)

# 源数据处理,将每条数据的每个属性分割组成list，每个list加入总LIST
data = []
for j in range(10):
    data.append([])
c = 0
# 分割数据 10分
for a in ll:
    temp = a.split(",")
    temp[6] = temp[6][:-1]
    data[c % 10].append(temp)
    c += 1
    pass

aver = dict(aver=0)
for j in range(10):
    # 属性对应条件概率数据结构，使用字典嵌套
    buying: Dict[Any, Dict[Any, int]] = \
        dict(unacc=dict(vhigh=0, high=0, med=0, low=0, tol=0),
             acc=dict(vhigh=0, high=0, med=0, low=0, tol=0),
             good=dict(vhigh=0, high=0, med=0, low=0, tol=0),
             vgood=dict(vhigh=0, high=0, med=0, low=0, tol=0))
    maint: Dict[Any, Dict[Any, int]] = \
        dict(unacc=dict(vhigh=0, high=0, med=0, low=0, tol=0),
             acc=dict(vhigh=0, high=0, med=0, low=0, tol=0),
             good=dict(vhigh=0, high=0, med=0, low=0, tol=0),
             vgood=dict(vhigh=0, high=0, med=0, low=0, tol=0))
    door: Dict[Any, Dict[Any, int]] = \
        dict(unacc={'2': 0, '3': 0, '4': 0, '5more': 0, 'tol': 0},
             acc={'2': 0, '3': 0, '4': 0, '5more': 0, 'tol': 0},
             good={'2': 0, '3': 0, '4': 0, '5more': 0, 'tol': 0},
             vgood={'2': 0, '3': 0, '4': 0, '5more': 0, 'tol': 0})
    person: Dict[Any, Dict[Any, int]] = \
        dict(unacc={'2': 0, '4': 0, 'more': 0, 'tol': 0},
             acc={'2': 0, '4': 0, 'more': 0, 'tol': 0},
             good={'2': 0, '4': 0, 'more': 0, 'tol': 0},
             vgood={'2': 0, '4': 0, 'more': 0, 'tol': 0})
    lugboot: Dict[Any, Dict[Any, int]] = \
        dict(unacc=dict(small=0, med=0, big=0, tol=0),
             acc=dict(small=0, med=0, big=0, tol=0),
             good=dict(small=0, med=0, big=0, tol=0),
             vgood=dict(small=0, med=0, big=0, tol=0))
    safety: Dict[Any, Dict[Any, int]] = \
        dict(unacc=dict(low=0, med=0, high=0, tol=0),
             acc=dict(low=0, med=0, high=0, tol=0),
             good=dict(low=0, med=0, high=0, tol=0),
             vgood=dict(low=0, med=0, high=0, tol=0))
    # 先验概率
    px = dict(unacc=0, acc=0, good=0, vgood=0, tol=0)

    for i in range(9):
        train(data[(i + 1 + j) % 10], buying, maint, door, person, lugboot, safety, px)
    test(data[j], buying, maint, door, person, lugboot, safety, px, aver)
print(aver['aver']/10)
print('ok')
