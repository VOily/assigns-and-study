import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileEncAndDec {
    enum ALG{
        DES,AES;
    }
    private static int dataOfFile = 0;      // 文件字节内容
    private static String key = "1234abc";  //口令
    private static int[] array;             //存放每个hash值的数组

    public static void main(String[] args) {
        System.out.println(ALG.AES.toString().equals("AES"));
/*        File srcFile = new File("WEB.pptx"); // 初始文件
        File encFile = new File("WEB1.pptx"); // 加密文件
        File decFile = new File("WEB2.pptx"); // 解密文件

        //使用md5将口令生成hash后 hash转为ascii
        array = string2ASCII(getMD5(key));

        try {
            EncFile(srcFile, encFile);
            DecFile(encFile, decFile);
        } catch (Exception e) {
            e.printStackTrace();
        }*/

    }

    private static void EncFile(File srcFile, File encFile) throws Exception {
        //检查文件、创建加密文件
        if (!srcFile.exists()) {
            System.out.println("source file not exist");
            return;
        }
        if (!encFile.exists()) {
            if (!encFile.createNewFile()) {
                System.out.println("encrypt file creating failed");
                return;
            }
            System.out.println("encrypt file created");
        }
        //使用 inputstream 操作文件
        InputStream fis = new FileInputStream(srcFile);
        OutputStream fos = new FileOutputStream(encFile);

        int i = 0;
        while ((dataOfFile = fis.read()) > -1) {
            //亦或运算hash加密
            fos.write(dataOfFile ^ array[i++]);
            if (i == array.length - 1) i = 0;
        }
        System.out.println(i);

        fis.close();
        fos.flush();
        fos.close();
    }

    // 4176587
    private static void DecFile(File encFile, File decFile) throws Exception {
        if (!encFile.exists()) {
            System.out.println("encrypt file not exixt");
            return;
        }

        if (!decFile.exists()) {
            if (!decFile.createNewFile()) {
                System.out.println("decrypt file creating failed");
                return;
            }
            System.out.println("decrypt file created");
        }

        InputStream fis = new FileInputStream(encFile);
        OutputStream fos = new FileOutputStream(decFile);

        int i = 0;
        while ((dataOfFile = fis.read()) > -1) {
            //亦或运算hash解密
            fos.write(dataOfFile ^ array[i++]);
            if (i == array.length - 1) i = 0;
        }
        System.out.println(i + "");

        fis.close();
        fos.flush();
        fos.close();
    }

    //String2Ascii
    public static int[] string2ASCII(String s) {// 字符串转换为ASCII码
        if (s == null || "".equals(s)) {
            return null;
        }

        char[] chars = s.toCharArray();
        int[] asciiArray = new int[chars.length];

        for (int i = 0; i < chars.length; i++) {
            asciiArray[i] = char2ASCII(chars[i]);
        }
        return asciiArray;
    }

    public static int char2ASCII(char c) {
        return (int) c;
    }
    //产生摘要，用数据的摘要加密
    public static String getMD5(String sInput) {
        String algorithm = "";
        if (sInput == null) {
            return "null";
        }
        try {
            algorithm = System.getProperty("MD5.algorithm", "MD5");
        } catch (SecurityException se) {
            se.printStackTrace();
        }
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance(algorithm);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        byte buffer[] = sInput.getBytes();

        if (md != null) {
            for (int count = 0; count < sInput.length(); count++) {

                md.update(buffer, 0, count);

            }
            byte bDigest[] = md.digest();

            BigInteger bi = new BigInteger(bDigest);
            return (bi.toString(16));
        }
        return null;
    }
}
