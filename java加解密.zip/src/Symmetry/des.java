package Symmetry;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;

/**
 * ALGORITHM 算法 <br>
 * 可替换为以下任意一种算法，同时key值的size相应改变。
 *
 * <pre>
 * DES          		key size must be equal to 56
 * DESede(TripleDES) 	key size must be equal to 112 or 168
 * AES          		key size must be equal to 128, 192 or 256,but 192 and 256 bits may not be available
 * Blowfish     		key size must be multiple of 8, and can only range from 32 to 448 (inclusive)
 * RC2          		key size must be between 40 and 1024 bits
 * RC4(ARCFOUR) 		key size must be between 40 and 1024 bits
 *
 * 分组模式：
 * CBC EBC OFB CFB
 * </pre>
 *
 * 下述代码，从DES到其他加密算法
 * <code>SecretKey secretKey = new SecretKeySpec(key, ALGORITHM);</code>
 * 替换
 * <code>
 * DESKeySpec dks = new DESKeySpec(key);
 * SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM);
 * SecretKey secretKey = keyFactory.generateSecret(dks);
 * </code>
 *
 * cipher中transformation：
 * Java平台的每个实现都需要支持以下标准Cipher转换，括号中的键入：
 * AES/CBC/NoPadding （128） AES/CBC/PKCS5Padding （128） AES/ECB/NoPadding （128） AES/ECB/PKCS5Padding （128）
 * DES/CBC/NoPadding （56） DES/CBC/PKCS5Padding（56） DES/ECB/NoPadding（56） DES/ECB/PKCS5Padding （56）
 * DESede/CBC/NoPadding （168） DESede/CBC/PKCS5Padding （168） DESede/ECB/NoPadding （168） DESede/ECB/PKCS5Padding （168）
 * RSA/ECB/PKCS1Padding （ 1024，2048 ） RSA/ECB/OAEPWithSHA-1AndMGF1Padding （ 1024，2048 ） RSA/ECB/OAEPWithSHA-256AndMGF1Padding （ 1024，2048 ）
 * 这些转变在描述Cipher section Java加密体系结构标准算法名称的文档。 请参阅实施的发行文档，以查看是否支持其他转换。
 *
 * 加密时编码问题
 * 1、解密时生成的时byte数组的ascii
 * 2、中文进行编码处理(转成16进制)
 */
public class des {

    private static String  PAD = "PKCS5Padding";

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        String content = "liuqwdbsgifhbaerbfvuiaydgsvkja";
        //此处密码AES16位 des 只用前八位
        String key = "0123456712345678";
        //String key1 = "01234567456";
        String algo = "AES";//算法选择
        String block = "EBC";//分组模式选择

        System.out.println("before:" + byteToHexString(content.getBytes()));

        byte[] encrypted = DES_Encrypt(content.getBytes(), key.getBytes(), algo, block);

        System.out.println("after:" + byteToHexString(encrypted));

        byte[] decrypted = DES_Decrypt(encrypted, key.getBytes(), algo, block);

        System.out.println("end:" + byteToHexString(decrypted));
    }

    private static String toMode(String algor, String block) {
        switch (algor){
            case "DES":
            case "AES":
            case "DESede":
            case "Blowfish":
            case "RC4":
                switch (block){
                    case "CBC":
                    case "EBC":
                    case "OFB":
                    case "CFB":
                        return algor + "/" + block + "/" + PAD;
                    default:
                        System.out.println("wrong mode");
                        System.exit(0);
                        return null;
                }
            default:
                System.out.println("wrong mode");
                System.exit(0);
                return null;
        }
    }

    public static byte[] DES_Encrypt(byte[] content, byte[] keyBytes, String algor, String block) {
        try {
            //密钥的生成
            SecretKey key;   //秘密键， 提供所有类型的密钥 接口
            // ？keyfactory 和 spec区别？
            //spec包 指定算法的密钥 类
            DESKeySpec keySpec = null;
            if (algor.equals("DES")) {
                keySpec = new DESKeySpec(keyBytes); //指定DES密钥，只用八位
                SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algor);//密钥转换为规范密钥（双向）
                key = keyFactory.generateSecret(keySpec);  //生成规范密钥对象
            } else {
                //不检查（错则抛出异常）给定字节是否符合指定算法密钥规范（强弱等）应使用特定于算法的密钥规范类
                key = new SecretKeySpec(keyBytes, algor);
            }

            String mode = toMode(algor, block);
            //此处AES和DES在Cipher上略有不同  ？密钥包装？WRAP_MODE
            //Cipher：‘算法/模式/填充’or‘算法’(默认)
            Cipher cipher = Cipher.getInstance(algor);
            //Cipher cipher = Cipher.getInstance(mode);

            //根据mode进行密钥初始化
            // 此处还可加入Random和Parameter， 作为算法任何地方需要时的实现(随机数、填充、IV等)
            // CBC模式下的DES和具有OAEP编码操作的RSA密码可使用下面的IV
            // parameter: new IvParameterSpec(byte[] iv) 此处iv不能是null ？可以是任意长度？
            cipher.init(Cipher.ENCRYPT_MODE, key);

            return cipher.doFinal(content);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("exception:" + e.toString());
        }
        return null;
    }

    public static byte[] DES_Decrypt(byte[] content, byte[] keyBytes, String algor, String block) {
        try {
            SecretKey key;
            DESKeySpec keySpec = null;
            if (algor.equals("DES")) {
                keySpec = new DESKeySpec(keyBytes);
                SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algor);
                key = keyFactory.generateSecret(keySpec);
            } else {
                key = new SecretKeySpec(keyBytes, algor);
            }

            String mode = toMode(algor, block);
            Cipher cipher = Cipher.getInstance(algor);
            cipher.init(Cipher.DECRYPT_MODE, key);

            return cipher.doFinal(content);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("exception:" + e.toString());
        }
        return null;
    }

    public static String byteToHexString(byte[] bytes) {
        StringBuffer sb = new StringBuffer(bytes.length);
        String sTemp;
        for (byte aByte : bytes) {
            sTemp = Integer.toHexString(0xFF & aByte);
            if (sTemp.length() < 2)
                sb.append(0);
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }
}


