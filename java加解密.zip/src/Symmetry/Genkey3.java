package Symmetry;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.SecureRandom;
import java.util.*;

public class Genkey3 {
    public static void main(String args[]) {
        byte[] key = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        printKey(key);
    }

    public static void printKey(byte[] keyBytes){
        try{
            //��һ�֣�Factory
            DESKeySpec keySpec=new DESKeySpec(keyBytes);
            SecretKeyFactory keyFactory=SecretKeyFactory.getInstance("Symmetry");
            SecretKey key1=keyFactory.generateSecret(keySpec);

            //�ڶ���, Generator
            KeyGenerator keyGenerator=KeyGenerator.getInstance("Symmetry");
            keyGenerator.init(56, new SecureRandom(keyBytes));//keyΪ8���ֽڣ�ʵ������56λ�� �����������key��Ϊ����seed����
            SecretKey key2=keyGenerator.generateKey();

            //�����֣� SecretKeySpec
            SecretKey key3=new SecretKeySpec(keyBytes, "Symmetry");//SecretKeySpec��ͬʱʵ����Key��KeySpec�ӿ�

            //��ӡ
            System.out.println("key1:"+(Arrays.toString(key1.getEncoded())));
            System.out.println("key2:"+(Arrays.toString(key2.getEncoded())));
            System.out.println("key3:"+(Arrays.toString(key3.getEncoded())));

        }catch(Exception e){
            System.out.println(e.toString());
        }
    }
}
