# -*- coding: UTF-8 -*-

import socket, time, _thread  # 导入 socket 模块

def conn(s):
    host = socket.gethostname() # 获取本地主机名
    port = 12345                # 设置端口
    s.bind((host, port))        # 绑定端口
    print(host, ",port: ",port,"  is binded")
    s.listen(5)                 # 等待客户端连接

def get_key(c):
    key = c.recv(1024)
    print("the key is ", key.decode())
    return key

def thre(c, results1):#server to client
    for res1 in results1:
        d1=dict(res1)['full_line']
        c.send(dl.encode())
        print(d1)
    c.send(b"end")
    c.close()

'''
s = socket.socket()             # 创建 socket 对象
conn(s)
while True:
    c, addr = s.accept()        #主线程接受客户端对象
    print('连接地址：',addr)
    try:
        _thread.start_new_thread(thre, (c, 1))
    except:
        print ("Error: 无法启动线程")

print ("退出主线程")
'''
