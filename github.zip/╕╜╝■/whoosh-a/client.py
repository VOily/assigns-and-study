# -*- coding: UTF-8 -*-

import socket, time             # 导入 socket 模块

def conn(s):
    host = socket.gethostname() # 获取本地主机名
    port = 12345                # 设置端口号
    s.connect((host, port))

def sendkey(s,key):
    s.send(key.encode())

def result(s):                  #get the query's result
    while True:
        re=s.recv(1024)
        print(re.decode())
        if(re==b"end"):
            break
        
'''
s = socket.socket()             # 创建 socket 对象
conn(s)
sendkey(s, "query")
result(s)
s.close()  

'''
