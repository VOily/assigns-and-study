from whoosh.qparser import QueryParser  
from whoosh.index import create_in  
from whoosh.index import open_dir  
from whoosh.fields import *  
from jieba.analyse import ChineseAnalyzer  
#from get_comment import SQL  
from whoosh.sorting import FieldFacet  
  
analyser = ChineseAnalyzer()    #导入中文分词工具  
schema = Schema(phone_name=TEXT(stored=True, analyzer=analyser), price=NUMERIC(stored=True), phoneid=ID(stored=True))# 创建索引结构  
ix = create_in("indexpath", schema=schema, indexname='indexname1') #path 为索引创建的地址，indexname为索引名称  
writer = ix.writer()  
writer.add_document(phone_name='lg-400',price ="25",phoneid ="9") #  此处为添加的内容   
print("建立完成一个索引")  
writer.commit()  
# 以上为建立索引的过程 

new_list = []  
index = open_dir("indexpath", indexname='indexname1')  #读取建立好的索引  
with index.searcher() as searcher:  
    parser = QueryParser("phone_name", index.schema)  
    myquery = parser.parse("lg")  
    facet = FieldFacet("price", reverse=True)  #按序排列搜索结果  
    results = searcher.search(myquery, limit=None, sortedby=facet)  #limit为搜索结果的限制，默认为10，详见博客开头的官方文档  
    for result1 in results:  
        print(dict(result1))  
        new_list.append(dict(result1))