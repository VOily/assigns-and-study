
import os, sys, time

pipnc2s="/tmp/pip-c2s"
pipns2c="/tmp/pip-s2c"
pipfc2s=os.open(pipnc2s, os.O_RDWR)
pipfs2c=os.open(pipns2c, os.O_RDWR)
#time.sleep(999)
while True:
    req=os.read(pipfc2s, 4096000)
    print(req)
    os.write(pipfs2c, "res=cont1")
