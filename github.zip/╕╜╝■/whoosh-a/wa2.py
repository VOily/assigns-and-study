from whoosh.qparser import QueryParser  
from whoosh.index import create_in  
from whoosh.index import open_dir  
from whoosh.fields import *  
from jieba.analyse import ChineseAnalyzer  
#from get_comment import SQL  
from whoosh.sorting import FieldFacet  
  
# 导入中文分词工具
analyser = ChineseAnalyzer()
# 创建索引结构: 没有结构，就是很多文本文件，一行一行的，总之很多行
schema = Schema(full_line=TEXT(stored=True, analyzer=analyser))
# 数据和索引所在目录，以及索引名称  
ix = create_in("shegongku", schema=schema, indexname='allin1line')
# 多加几行
writer = ix.writer()  
writer.add_document(full_line='1,21605735,ゆ~~晴子~~,22,1,4,100100')
writer.add_document(full_line='2,32507773,黄璘,105,1,2,100100')
writer.add_document(full_line='3,389737625,niki,26,1,3,100100')
writer.add_document(full_line='4,10095,Paul,31,0,2,100100')
writer.add_document(full_line='5,795019031,一二三四五六,2,0,1,100100')
writer.add_document(full_line='6,251000782,赵耀,33,0,1,100100')
writer.add_document(full_line='7,750060112,taoeryu12,0,0,1,100100')
writer.add_document(full_line='8,375000016,洋洋沙沙[],0,1,1,100100')
writer.add_document(full_line='9,357489692,黄梅,1,1,1,100100')

writer.add_document(full_line='18296447,8,2006-01-02,兄弟群,162,')
writer.add_document(full_line='18296448,6,2005-12-09,倖福de摩天論,395,此地是霹雳无敌惊天动地翻江倒海天上没有地上无双的厨房四宝家族~~~~~~~~')
writer.add_document(full_line='18296450,20,2005-12-02,梦想Ψ医专,319,我是李胜涛。大家好')
writer.add_document(full_line='18296451,33,2005-12-02,广水四中九七三班,3,')
writer.add_document(full_line='18296452,35,2008-01-24,6班,395,11')
writer.add_document(full_line='18296453,4,2009-10-12,通海路中学2班,4278,通海路中学')
writer.add_document(full_line='18296454,3,2005-12-02,。。。。。,4087,http://www.allcombo.com/main/index.html')
writer.add_document(full_line='18296455,40,2006-06-18,快乐天地（11）,22,各位靓女靓仔可以张你地噶群名改成真名吗！甘样就知到你系边个拉！')

writer.add_document(full_line='kdh2003@163.com----325565')
writer.add_document(full_line='k403368852@163.com----aaa4870')
writer.add_document(full_line='kakayaya-svs@163.com----wuzi55')
writer.add_document(full_line='ksclf@163.com----4520228')
writer.add_document(full_line='kelly5210.happy@163.com----5201314')
writer.add_document(full_line='kaikaikuanglong@163.com----buyaoqipianwo')
writer.add_document(full_line='kyzy003_3@163.com----197233')
writer.add_document(full_line='kill11911llki1l9@163.com----627038')
writer.add_document(full_line='kitty413love@163.com----123456')

print("建立索引finished")
writer.commit()  
# 以上为建立索引的过程 

new_list = []  
index = open_dir("shegongku", indexname='allin1line')
with index.searcher() as searcher:  
    parser = QueryParser("full_line", index.schema)
    myquery = parser.parse("班")  
    results = searcher.search(myquery, limit=None)
    for result1 in results:  
        print(dict(result1))  
        new_list.append(dict(result1))
