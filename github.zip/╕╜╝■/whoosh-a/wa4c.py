#!/usr/bin/python3
# -*- coding:utf-8 -*-
import io,os,sys,cgi,time, client
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8')

print("Content-type: text/html")
print("")
print('<html><head>')
print('<meta charset="UTF-8">')
print('</head><body>')
print("<pre>")
print("partly from 163 and qqqun")
#print("$QUERY_STRING is ", os.getenv("QUERY_STRING"))

fs = cgi.FieldStorage()
key1=fs.getvalue('keyw')
print("key word is", key1)
print("")
s = socket.socket()             # 创建 socket 对象
conn(s)
yesa=True
for c in key1 :
    if ord(c)>=128:
        yesa=False
        break
#以下为发出传送信息接受结果
if yesa:
    sendkey(s, key1.encode())
    time.sleep(3)
    result(s)
    print("ok")
else:
    print("bad key word, only ascii keyword is allowed for now")
    print("who can help to surpport non-ascii, pls qq me.")
print('<pre></body></html>')
