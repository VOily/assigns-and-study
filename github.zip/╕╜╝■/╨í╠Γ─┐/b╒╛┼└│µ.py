import urllib2
import json

# 注意 1056,修改这个数字得到其他视频集
jsonurl = "https://bangumi.bilibili.com/jsonp/seasoninfo/1056.ver?callback=seasonListCallback&jsonp=jsonp"

data = urllib2.urlopen(jsonurl).read()

first = data.index("{")
last = data.rindex("}")
json_data = data[first:last+1]

j = json.loads(json_data)
list = j['result']['episodes']

for item in list:
    print(item['index']," ",item['index_title']," ",item['webplay_url'])
