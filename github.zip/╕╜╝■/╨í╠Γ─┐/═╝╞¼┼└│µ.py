import requests, json, time, sys
from contextlib import closing
'''
在动态加载图片的网站爬图片
需要确定网站图片存放位置（查看json请求数据 有无图片描述），
    目标图片的id（图片的地址除了id不同其他相似）
获取解析json的数据（1、认证报错（设为false） 2、反爬虫机制（authorization的id验证，设置header））#此处可获得图片id 用json包中load（req.text）提取


'''
class get_photos(object):

    def __init__(self):
        self.photos_id = []
        self.download_server = 'https://unsplash.com/photos/xxx/download?force=trues'
        self.target = 'http://unsplash.com/napi/feeds/home'
        #反爬虫机制：authorization 服务器为用户分配ID，通过验证后才能访问
        self.headers = {'authorization':'your Client-ID'}#此处需要Fidder抓包查看security下的authorization的ID
        
        """
        函数说明:获取图片ID
        Parameters:
            无
        Returns:
            无
        Modify:
            2017-09-13
        """ 
        def get_ids(self):
            req = requests.get(url=self.target, headers=self.headers, verify=False)
            html = json.loads(req.text)
            next_page = html['next_page']
            for each in html['photos']:
                self.photos_id.append(each['id'])
            time.sleep(1)
            for i in range(4):
                req = requests.get(url=next_page, headers=self.headers, verify=False)
                html = json.loads(req.text)
                next_page = html['next_page']
                for each in html['photos']:
                    self.photos_id.append(each['id'])
                time.sleep(1)


        """
        函数说明:图片下载
        Parameters:
            无
        Returns:
            无
        Modify:
            2017-09-13
        """ 
        def download(self, photo_id, filename):
            headers = {'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'}
            target = self.download_server.replace('xxx', photo_id)
            with closing(requests.get(url=target, stream=True, verify = False, headers = self.headers)) as r:
                with open('%d.jpg' % filename, 'ab+') as f:
                    for chunk in r.iter_content(chunk_size = 1024):
                        if chunk:
                            f.write(chunk)
                            f.flush()

    if __name__ == '__main__':
        gp = get_photos()
        print('获取图片连接中:')
        gp.get_ids()
        print('图片下载中:')
        for i in range(len(gp.photos_id)):
            print('  正在下载第%d张图片' % (i+1))
            gp.download(gp.photos_id[i], (i+1))
