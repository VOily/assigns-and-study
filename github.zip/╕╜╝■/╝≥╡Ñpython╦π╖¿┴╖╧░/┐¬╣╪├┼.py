def cal(time):
    return int(time[0:2])*10000+int(time[3:5])*100+int(time[6:])


n = int(input("天数"))
for j in range(n):
    m = int(input("条数"))
    first = 999999
    fid = ""
    last = -1
    lid = ""
    for i in range(m):
        id = input("ID")
        arrive = input("arrive")
        if cal(arrive) < first:  #比较开门时间
            fid = id
            first = cal(arrive)
        leave = input("leave")
        if cal(leave) > last:    #比较关门时间
            lid = id
            last = cal(leave)
        pass
    print("day:", j+1, "\nfirst is:", fid, "last is:", lid)
