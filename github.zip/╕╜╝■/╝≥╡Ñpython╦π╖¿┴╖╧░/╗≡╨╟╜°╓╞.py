primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31,
          37, 41, 43, 47, 53, 59, 61, 67, 71, 73,
          79, 83, 89, 97, 101]
n = int(input())
for i in primes:
    if n == 0:
        break
    print(n%i)
    n = int(n/i)



