num = input("人数")
i = int(num)
all = int(input("成绩"))
max = all
min = all
while i>1:
    temp = int(input("成绩"))
    all += temp
    if(max<temp):
        max = temp
    if(min>temp):
        min = temp
    i = i-1
    pass
all -= max
all -= min
print(round(all/int(num),2))