n = int(input("个数"))
m = int(input("插入数"))
flag = 1
for i in range(n):
    x = int(input("数"))
    if(x>m & flag):
        print(m)
        flag=0
    print(x)
    pass
if(flag):
    print(m)