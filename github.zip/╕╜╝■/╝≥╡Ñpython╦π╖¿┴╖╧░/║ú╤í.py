m = int(input("行数"))
n = int(input("列数"))
i = 1
j = 1
max = 0
for l in range(m*n):
    x = int(input("分数"))
    if(abs(x)>max):
        max = abs(x)
        j = l%m+1
        i = int(l/m)+1
    pass
print("行数", i, " 列数", j)